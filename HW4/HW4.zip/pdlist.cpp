/*  Author: Chen Xianwei
 *  Zhejiang University
 *  Date:2019-04-08 10:46:18
 *  Version:1.0
 *  Description:

 */

#include "diary.h"

#define DIARY_NAME "diary.txt"

int main(int argc, char *argv[])
{
	print_all(DIARY_NAME);
	return 0;
}